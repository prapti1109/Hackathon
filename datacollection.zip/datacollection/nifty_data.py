import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

# Define the stock symbol for Nifty 50
symbol = '^NSEI'  # Nifty 50 index symbol

# Calculate dates for past 30 years
end_date = datetime.now().strftime('%Y-%m-%d')
start_date = (datetime.now() - timedelta(days=365.25 * 30)).strftime('%Y-%m-%d')

print(f"Fetching Nifty 50 data from {start_date} to {end_date}")

# Fetch the historical data
nifty50 = yf.Ticker(symbol)
data = nifty50.history(start=start_date, end=end_date, interval='1d')  # Daily data for 30 years

# Display the first few rows
print(data.head())

# Save to CSV file
csv_filename = 'nifty50_30years.csv'
data.to_csv(csv_filename)

print(f"Data saved to {csv_filename}")
print(f"Total records: {len(data)}")