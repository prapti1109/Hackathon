import torch
import torch.nn as nn
from transformers import BertTokenizer, BertModel
import json

# Use GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Define a sentiment classifier built on a pre-trained BERT model
class SentimentClassifier(nn.Module):
    def __init__(self, hidden_size=768, num_classes=3):
        super(SentimentClassifier, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-uncased')
        self.dropout = nn.Dropout(0.3)
        self.fc = nn.Linear(hidden_size, num_classes)
        
    def forward(self, input_ids, attention_mask, token_type_ids=None):
        outputs = self.bert(
            input_ids=input_ids, 
            attention_mask=attention_mask, 
            token_type_ids=token_type_ids
        )
        pooled_output = outputs.pooler_output
        dropout_output = self.dropout(pooled_output)
        logits = self.fc(dropout_output)
        return logits

# Initialize tokenizer and model
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = SentimentClassifier()
model.to(device)
model.eval()  # Switch model to evaluation mode

def predict_sentiment(text):
    """
    Tokenizes the input text and uses the classifier to predict sentiment.
    The classifier outputs one of three classes:
      0 -> "negative", 1 -> "stable", 2 -> "positive"
    """
    inputs = tokenizer(
        text,
        return_tensors='pt',
        max_length=128,
        truncation=True,
        padding='max_length'
    )
    # Move inputs to the selected device
    inputs = {key: value.to(device) for key, value in inputs.items()}
    
    with torch.no_grad():
        outputs = model(**inputs)
        prediction = torch.argmax(outputs, dim=1).item()
    
    sentiment_map = {0: "negative", 1: "stable", 2: "positive"}
    return sentiment_map.get(prediction, "stable")

def process_news_data(file_path):
    """
    Processes news data from a JSONL file.
    Each line should contain a JSON object with at least 'timestamp' and 'news' keys.
    For each news item, the text is used to predict a sentiment label.
    """
    results = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            data = json.loads(line)
            news_text = data.get('news', "")
            timestamp = data.get('timestamp', "")
            sentiment = predict_sentiment(news_text)
            results.append({"timestamp": timestamp, "sentiment": sentiment})
            print(f"Timestamp: {timestamp} | Sentiment: {sentiment}")
    return results

if __name__ == "__main__":
    # Provide the path to your JSONL file containing the news data.
    file_path = "/kaggle/input/traindataset/train.jsonl"
    process_news_data(file_path)