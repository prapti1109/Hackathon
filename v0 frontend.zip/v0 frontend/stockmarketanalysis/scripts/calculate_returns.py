#!/usr/bin/env python
"""
Script to calculate potential returns for stock holdings.
Usage: python calculate_returns.py '[{"symbol":"AAPL","quantity":10,"purchasePrice":150}]'
"""

import sys
import json
import random

def get_current_prices(symbols):
    """
    Get current prices for the given symbols.
    In a real implementation, you would use a library like yfinance or connect to a stock API.
    """
    # Mock data for demonstration
    mock_prices = {
        "AAPL": 182.52,
        "MSFT": 417.88,
        "GOOGL": 152.19,
        "AMZN": 178.75,
        "META": 474.99,
        "TSLA": 177.50,
        "NVDA": 925.75,
        "BRK.B": 408.32,
        "JPM": 198.47,
        "V": 275.96
    }
    
    result = {}
    for symbol in symbols:
        # Use mock price if available, otherwise generate a random price
        if symbol in mock_prices:
            result[symbol] = mock_prices[symbol]
        else:
            result[symbol] = round(random.uniform(50, 500), 2)
    
    return result

def calculate_returns(holdings):
    """
    Calculate returns for each holding based on current prices.
    """
    # Extract symbols for price lookup
    symbols = [holding["symbol"] for holding in holdings]
    
    # Get current prices
    current_prices = get_current_prices(symbols)
    
    # Calculate returns for each holding
    results = []
    for holding in holdings:
        symbol = holding["symbol"]
        quantity = holding["quantity"]
        purchase_price = holding["purchasePrice"]
        
        current_price = current_prices.get(symbol)
        
        if current_price:
            investment_value = purchase_price * quantity
            current_value = current_price * quantity
            return_value = current_value - investment_value
            return_percentage = (return_value / investment_value) * 100 if investment_value > 0 else 0
            
            results.append({
                "id": holding.get("id", ""),
                "symbol": symbol,
                "currentPrice": current_price,
                "currentValue": current_value,
                "returnValue": return_value,
                "returnPercentage": return_percentage
            })
    
    return results

if __name__ == "__main__":
    # Get holdings data from command line argument
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No holdings data provided"}))
        sys.exit(1)
    
    try:
        holdings_json = sys.argv[1]
        holdings = json.loads(holdings_json)
        
        results = calculate_returns(holdings)
        print(json.dumps({"results": results}))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)

