#!/usr/bin/env python
"""
Script to fetch current stock prices.
Usage: python get_stock_prices.py AAPL MSFT GOOGL
"""

import sys
import json
import random

def get_mock_prices(symbols):
    """
    Mock function to get current prices.
    In a real implementation, you would use a library like yfinance or connect to a stock API.
    """
    # Real implementation would use:
    # import yfinance as yf
    # data = yf.download(symbols, period="1d")
    # prices = data['Close'].to_dict()
    
    # Mock data for demonstration
    mock_prices = {
        "AAPL": 182.52,
        "MSFT": 417.88,
        "GOOGL": 152.19,
        "AMZN": 178.75,
        "META": 474.99,
        "TSLA": 177.50,
        "NVDA": 925.75,
        "BRK.B": 408.32,
        "JPM": 198.47,
        "V": 275.96
    }
    
    result = {}
    for symbol in symbols:
        # Use mock price if available, otherwise generate a random price
        if symbol in mock_prices:
            result[symbol] = mock_prices[symbol]
        else:
            result[symbol] = round(random.uniform(50, 500), 2)
    
    return result

if __name__ == "__main__":
    # Get symbols from command line arguments
    symbols = sys.argv[1:] if len(sys.argv) > 1 else []
    
    if not symbols:
        print(json.dumps({"error": "No symbols provided"}))
        sys.exit(1)
    
    try:
        prices = get_mock_prices(symbols)
        print(json.dumps({"prices": prices}))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)

