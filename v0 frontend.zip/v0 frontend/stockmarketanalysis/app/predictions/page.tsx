"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, LucideLineChart, BarChart3, PieChart, ArrowUp, ArrowDown } from "lucide-react"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

export default function PredictionsPage() {
  const [searchQuery, setSearchQuery] = useState("")

  // Mock data for stock predictions
  const stockPredictions = [
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      currentPrice: 182.52,
      prediction: 195.0,
      confidence: 85,
      sentiment: "Bullish",
    },
    {
      symbol: "MSFT",
      name: "Microsoft Corp.",
      currentPrice: 417.88,
      prediction: 440.0,
      confidence: 78,
      sentiment: "Bullish",
    },
    {
      symbol: "GOOGL",
      name: "Alphabet Inc.",
      currentPrice: 152.19,
      prediction: 165.0,
      confidence: 72,
      sentiment: "Bullish",
    },
    {
      symbol: "AMZN",
      name: "Amazon.com Inc.",
      currentPrice: 178.75,
      prediction: 190.0,
      confidence: 80,
      sentiment: "Bullish",
    },
    {
      symbol: "META",
      name: "Meta Platforms Inc.",
      currentPrice: 474.99,
      prediction: 460.0,
      confidence: 65,
      sentiment: "Bearish",
    },
    {
      symbol: "TSLA",
      name: "Tesla Inc.",
      currentPrice: 177.5,
      prediction: 200.0,
      confidence: 68,
      sentiment: "Bullish",
    },
  ]

  // Mock historical data for charts
  const historicalData = [
    { date: "Jan", price: 150, prediction: 155 },
    { date: "Feb", price: 155, prediction: 160 },
    { date: "Mar", price: 160, prediction: 165 },
    { date: "Apr", price: 158, prediction: 163 },
    { date: "May", price: 162, prediction: 167 },
    { date: "Jun", price: 165, prediction: 170 },
    { date: "Jul", price: 170, prediction: 175 },
    { date: "Aug", price: 175, prediction: 180 },
    { date: "Sep", price: 180, prediction: 185 },
    { date: "Oct", price: 182, prediction: 190 },
    { date: "Nov", price: null, prediction: 195 },
    { date: "Dec", price: null, prediction: 200 },
  ]

  // Mock sentiment analysis data
  const sentimentData = [
    { source: "News Articles", positive: 65, neutral: 25, negative: 10 },
    { source: "Social Media", positive: 55, neutral: 30, negative: 15 },
    { source: "Analyst Reports", positive: 70, neutral: 20, negative: 10 },
    { source: "Financial Blogs", positive: 60, neutral: 25, negative: 15 },
  ]

  // Filter stocks based on search query
  const filteredStocks = stockPredictions.filter(
    (stock) =>
      stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stock.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container py-6 space-y-8">
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-3xl font-bold tracking-tight">Stock Predictions</h1>
          <div className="relative w-full sm:w-64 md:w-80">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search stocks..."
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredStocks.map((stock) => (
            <Card key={stock.symbol} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{stock.symbol}</CardTitle>
                    <CardDescription>{stock.name}</CardDescription>
                  </div>
                  <Badge variant={stock.sentiment === "Bullish" ? "default" : "destructive"}>{stock.sentiment}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-sm text-muted-foreground">Current Price</div>
                      <div className="text-xl font-bold">${stock.currentPrice.toFixed(2)}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Prediction (30d)</div>
                      <div className="text-xl font-bold flex items-center justify-end">
                        ${stock.prediction.toFixed(2)}
                        {stock.prediction > stock.currentPrice ? (
                          <ArrowUp className="ml-1 h-5 w-5 text-green-500" />
                        ) : (
                          <ArrowDown className="ml-1 h-5 w-5 text-red-500" />
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="h-[100px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={historicalData}>
                        <defs>
                          <linearGradient id={`gradient-${stock.symbol}`} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="date" hide />
                        <YAxis hide domain={["auto", "auto"]} />
                        <Tooltip content={<CustomTooltip />} />
                        <Area
                          type="monotone"
                          dataKey="price"
                          stroke="hsl(var(--primary))"
                          fillOpacity={1}
                          fill={`url(#gradient-${stock.symbol})`}
                        />
                        <Area
                          type="monotone"
                          dataKey="prediction"
                          stroke="hsl(var(--primary))"
                          strokeDasharray="5 5"
                          fill="transparent"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      Confidence: <span className="font-medium">{stock.confidence}%</span>
                    </div>
                    <Button size="sm" variant="outline">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <Card>
          <CardHeader>
            <CardTitle>Detailed Stock Analysis</CardTitle>
            <CardDescription>
              Select a stock to view detailed prediction analysis and historical performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="price-prediction">
              <TabsList className="mb-4">
                <TabsTrigger value="price-prediction">
                  <LucideLineChart className="h-4 w-4 mr-2" />
                  Price Prediction
                </TabsTrigger>
                <TabsTrigger value="sentiment-analysis">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Sentiment Analysis
                </TabsTrigger>
                <TabsTrigger value="technical-indicators">
                  <PieChart className="h-4 w-4 mr-2" />
                  Technical Indicators
                </TabsTrigger>
              </TabsList>

              <TabsContent value="price-prediction">
                <div className="h-[400px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={historicalData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="price"
                        name="Historical Price"
                        stroke="hsl(var(--primary))"
                        activeDot={{ r: 8 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="prediction"
                        name="Predicted Price"
                        stroke="hsl(var(--destructive))"
                        strokeDasharray="5 5"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>

              <TabsContent value="sentiment-analysis">
                <div className="h-[400px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sentimentData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="source" />
                      <YAxis />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="positive" name="Positive" fill="hsl(var(--success))" />
                      <Bar dataKey="neutral" name="Neutral" fill="hsl(var(--muted-foreground))" />
                      <Bar dataKey="negative" name="Negative" fill="hsl(var(--destructive))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>

              <TabsContent value="technical-indicators">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Moving Averages</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>MA (20)</span>
                          <span className="font-medium text-green-500">Buy</span>
                        </div>
                        <div className="flex justify-between">
                          <span>MA (50)</span>
                          <span className="font-medium text-green-500">Buy</span>
                        </div>
                        <div className="flex justify-between">
                          <span>MA (100)</span>
                          <span className="font-medium text-green-500">Buy</span>
                        </div>
                        <div className="flex justify-between">
                          <span>MA (200)</span>
                          <span className="font-medium text-muted-foreground">Neutral</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Oscillators</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>RSI (14)</span>
                          <span className="font-medium text-muted-foreground">Neutral</span>
                        </div>
                        <div className="flex justify-between">
                          <span>MACD</span>
                          <span className="font-medium text-green-500">Buy</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Stochastic</span>
                          <span className="font-medium text-red-500">Sell</span>
                        </div>
                        <div className="flex justify-between">
                          <span>CCI</span>
                          <span className="font-medium text-muted-foreground">Neutral</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-md shadow-sm p-2 text-sm">
        <p className="font-medium">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {entry.name}: ${entry.value?.toFixed(2) || "N/A"}
          </p>
        ))}
      </div>
    )
  }

  return null
}

