"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowUp, ArrowDown, DollarSign, TrendingUp, BarChart3, PieChart } from "lucide-react"
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

export default function DashboardPage() {
  // Mock data for financial metrics
  const portfolioMetrics = {
    totalValue: 125750.42,
    dailyChange: 1250.32,
    dailyChangePercent: 1.01,
    monthlyChange: 3750.89,
    monthlyChangePercent: 3.08,
    yearlyChange: 15250.42,
    yearlyChangePercent: 13.8,
  }

  const assetAllocation = [
    { name: "Stocks", value: 65 },
    { name: "Bonds", value: 15 },
    { name: "Cash", value: 10 },
    { name: "Crypto", value: 5 },
    { name: "Real Estate", value: 5 },
  ]

  const sectorAllocation = [
    { name: "Technology", value: 35 },
    { name: "Healthcare", value: 20 },
    { name: "Financials", value: 15 },
    { name: "Consumer Discretionary", value: 10 },
    { name: "Industrials", value: 10 },
    { name: "Other", value: 10 },
  ]

  const performanceData = [
    { month: "Jan", portfolio: 5.2, benchmark: 4.8 },
    { month: "Feb", portfolio: 3.1, benchmark: 2.7 },
    { month: "Mar", portfolio: -1.5, benchmark: -2.1 },
    { month: "Apr", portfolio: 2.3, benchmark: 1.9 },
    { month: "May", portfolio: 4.5, benchmark: 3.8 },
    { month: "Jun", portfolio: 1.2, benchmark: 0.9 },
    { month: "Jul", portfolio: 3.7, benchmark: 3.2 },
    { month: "Aug", portfolio: -0.8, benchmark: -1.2 },
    { month: "Sep", portfolio: 2.9, benchmark: 2.5 },
    { month: "Oct", portfolio: 3.5, benchmark: 3.0 },
    { month: "Nov", portfolio: 4.1, benchmark: 3.6 },
    { month: "Dec", portfolio: 2.8, benchmark: 2.3 },
  ]

  const riskMetrics = [
    { name: "Alpha", value: 2.3 },
    { name: "Beta", value: 0.85 },
    { name: "Sharpe Ratio", value: 1.75 },
    { name: "Volatility", value: 12.5 },
    { name: "Max Drawdown", value: -15.2 },
  ]

  const topHoldings = [
    { symbol: "AAPL", name: "Apple Inc.", allocation: 8.5, performance: 12.3 },
    { symbol: "MSFT", name: "Microsoft Corp.", allocation: 7.2, performance: 15.8 },
    { symbol: "AMZN", name: "Amazon.com Inc.", allocation: 6.8, performance: 9.7 },
    { symbol: "GOOGL", name: "Alphabet Inc.", allocation: 5.5, performance: 7.2 },
    { symbol: "NVDA", name: "NVIDIA Corp.", allocation: 4.9, performance: 25.3 },
  ]

  // Colors for pie charts
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d"]

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight">Financial Dashboard</h1>
        <div className="flex items-center gap-2">
          <Select defaultValue="1M">
            <SelectTrigger className="w-[100px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1W">1 Week</SelectItem>
              <SelectItem value="1M">1 Month</SelectItem>
              <SelectItem value="3M">3 Months</SelectItem>
              <SelectItem value="6M">6 Months</SelectItem>
              <SelectItem value="1Y">1 Year</SelectItem>
              <SelectItem value="ALL">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${portfolioMetrics.totalValue.toLocaleString()}</div>
            <div className="flex items-center pt-1">
              {portfolioMetrics.dailyChange >= 0 ? (
                <>
                  <ArrowUp className="h-4 w-4 text-green-500" />
                  <span className="text-xs text-green-500">
                    +${portfolioMetrics.dailyChange.toLocaleString()} ({portfolioMetrics.dailyChangePercent}%)
                  </span>
                </>
              ) : (
                <>
                  <ArrowDown className="h-4 w-4 text-red-500" />
                  <span className="text-xs text-red-500">
                    -${Math.abs(portfolioMetrics.dailyChange).toLocaleString()} (
                    {Math.abs(portfolioMetrics.dailyChangePercent)}%)
                  </span>
                </>
              )}
              <span className="text-xs text-muted-foreground ml-1">Today</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Monthly Performance</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {portfolioMetrics.monthlyChangePercent >= 0 ? "+" : ""}
              {portfolioMetrics.monthlyChangePercent}%
            </div>
            <div className="flex items-center pt-1">
              {portfolioMetrics.monthlyChange >= 0 ? (
                <>
                  <ArrowUp className="h-4 w-4 text-green-500" />
                  <span className="text-xs text-green-500">+${portfolioMetrics.monthlyChange.toLocaleString()}</span>
                </>
              ) : (
                <>
                  <ArrowDown className="h-4 w-4 text-red-500" />
                  <span className="text-xs text-red-500">
                    -${Math.abs(portfolioMetrics.monthlyChange).toLocaleString()}
                  </span>
                </>
              )}
              <span className="text-xs text-muted-foreground ml-1">Last 30 days</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Yearly Performance</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {portfolioMetrics.yearlyChangePercent >= 0 ? "+" : ""}
              {portfolioMetrics.yearlyChangePercent}%
            </div>
            <div className="flex items-center pt-1">
              {portfolioMetrics.yearlyChange >= 0 ? (
                <>
                  <ArrowUp className="h-4 w-4 text-green-500" />
                  <span className="text-xs text-green-500">+${portfolioMetrics.yearlyChange.toLocaleString()}</span>
                </>
              ) : (
                <>
                  <ArrowDown className="h-4 w-4 text-red-500" />
                  <span className="text-xs text-red-500">
                    -${Math.abs(portfolioMetrics.yearlyChange).toLocaleString()}
                  </span>
                </>
              )}
              <span className="text-xs text-muted-foreground ml-1">Year to date</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Risk Level</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Moderate</div>
            <div className="flex items-center pt-1">
              <Badge variant="outline" className="text-xs">
                Beta: 0.85
              </Badge>
              <Badge variant="outline" className="text-xs ml-2">
                Volatility: 12.5%
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Portfolio Performance</CardTitle>
            <CardDescription>Comparison with benchmark index (S&P 500)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis tickFormatter={(value) => `${value}%`} />
                  <Tooltip formatter={(value) => [`${value}%`, ""]} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="portfolio"
                    name="Your Portfolio"
                    stroke="hsl(var(--primary))"
                    activeDot={{ r: 8 }}
                  />
                  <Line type="monotone" dataKey="benchmark" name="S&P 500" stroke="hsl(var(--muted-foreground))" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Asset Allocation</CardTitle>
            <CardDescription>Distribution across asset classes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={assetAllocation}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {assetAllocation.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value}%`, "Allocation"]} />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top Holdings</CardTitle>
            <CardDescription>Your best performing investments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topHoldings.map((holding) => (
                <div key={holding.symbol} className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{holding.symbol}</div>
                    <div className="text-sm text-muted-foreground">{holding.name}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{holding.allocation}%</div>
                    <div className={holding.performance >= 0 ? "text-green-500" : "text-red-500"}>
                      {holding.performance >= 0 ? "+" : ""}
                      {holding.performance}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sector Allocation</CardTitle>
            <CardDescription>Distribution across market sectors</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart layout="vertical" data={sectorAllocation} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tickFormatter={(value) => `${value}%`} />
                  <YAxis type="category" dataKey="name" width={100} />
                  <Tooltip formatter={(value) => [`${value}%`, "Allocation"]} />
                  <Bar dataKey="value" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Analysis</CardTitle>
          <CardDescription>Key risk metrics for your portfolio</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="metrics">
            <TabsList className="mb-4">
              <TabsTrigger value="metrics">Risk Metrics</TabsTrigger>
              <TabsTrigger value="comparison">Benchmark Comparison</TabsTrigger>
              <TabsTrigger value="historical">Historical Volatility</TabsTrigger>
            </TabsList>

            <TabsContent value="metrics">
              <div className="grid gap-6 md:grid-cols-5">
                {riskMetrics.map((metric) => (
                  <Card key={metric.name}>
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <div className="text-2xl font-bold">
                        {metric.value}
                        {metric.name === "Volatility" || metric.name === "Max Drawdown" ? "%" : ""}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {metric.name === "Alpha" && "Outperformance vs. benchmark"}
                        {metric.name === "Beta" && "Market sensitivity"}
                        {metric.name === "Sharpe Ratio" && "Risk-adjusted return"}
                        {metric.name === "Volatility" && "Price fluctuation"}
                        {metric.name === "Max Drawdown" && "Largest decline"}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="comparison">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { name: "Return", portfolio: 13.8, benchmark: 10.5 },
                      { name: "Risk", portfolio: 12.5, benchmark: 14.2 },
                      { name: "Sharpe", portfolio: 1.75, benchmark: 1.2 },
                      { name: "Alpha", portfolio: 2.3, benchmark: 0 },
                      { name: "Beta", portfolio: 0.85, benchmark: 1 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="portfolio" name="Your Portfolio" fill="hsl(var(--primary))" />
                    <Bar dataKey="benchmark" name="S&P 500" fill="hsl(var(--muted-foreground))" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>

            <TabsContent value="historical">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={[
                      { month: "Jan", volatility: 10.2 },
                      { month: "Feb", volatility: 11.5 },
                      { month: "Mar", volatility: 15.8 },
                      { month: "Apr", volatility: 14.2 },
                      { month: "May", volatility: 12.7 },
                      { month: "Jun", volatility: 11.9 },
                      { month: "Jul", volatility: 10.5 },
                      { month: "Aug", volatility: 12.1 },
                      { month: "Sep", volatility: 13.4 },
                      { month: "Oct", volatility: 12.8 },
                      { month: "Nov", volatility: 11.2 },
                      { month: "Dec", volatility: 10.8 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis tickFormatter={(value) => `${value}%`} />
                    <Tooltip formatter={(value) => [`${value}%`, "Volatility"]} />
                    <defs>
                      <linearGradient id="colorVol" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="volatility"
                      stroke="hsl(var(--primary))"
                      fillOpacity={1}
                      fill="url(#colorVol)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

