"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowUp, ArrowDown, Plus, Trash2, Calculator, RefreshCw } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { DatePicker } from "@/components/date-picker"
import { type StockHolding, calculateReturns, mockCalculateReturns } from "../actions/portfolio"
import { useToast } from "@/components/ui/use-toast"

export default function PortfolioPage() {
  // State for form inputs
  const [symbol, setSymbol] = useState("")
  const [name, setName] = useState("")
  const [purchaseDate, setPurchaseDate] = useState<Date | undefined>(new Date())
  const [purchasePrice, setPurchasePrice] = useState("")
  const [quantity, setQuantity] = useState("")

  // State for portfolio holdings
  const [holdings, setHoldings] = useState<StockHolding[]>([
    {
      id: "1",
      symbol: "AAPL",
      name: "Apple Inc.",
      purchaseDate: new Date("2023-01-15"),
      purchasePrice: 142.5,
      quantity: 10,
      currentPrice: null,
    },
    {
      id: "2",
      symbol: "MSFT",
      name: "Microsoft Corp.",
      purchaseDate: new Date("2023-03-22"),
      purchasePrice: 280.25,
      quantity: 5,
      currentPrice: null,
    },
    {
      id: "3",
      symbol: "GOOGL",
      name: "Alphabet Inc.",
      purchaseDate: new Date("2023-05-10"),
      purchasePrice: 105.75,
      quantity: 8,
      currentPrice: null,
    },
  ])

  // Loading states
  const [isCalculating, setIsCalculating] = useState(false)
  const [isCalculatingAll, setIsCalculatingAll] = useState(false)
  const [calculatingIds, setCalculatingIds] = useState<string[]>([])

  const { toast } = useToast()

  // Calculate total portfolio value
  const totalInvestment = holdings.reduce((sum, stock) => sum + stock.purchasePrice * stock.quantity, 0)
  const totalCurrentValue = holdings.reduce((sum, stock) => {
    if (stock.currentPrice) {
      return sum + stock.currentPrice * stock.quantity
    }
    return sum
  }, 0)
  const totalReturn = totalCurrentValue - totalInvestment
  const totalReturnPercentage = totalInvestment > 0 ? (totalReturn / totalInvestment) * 100 : 0

  // Add a new stock to portfolio
  const addStock = () => {
    if (!symbol || !name || !purchaseDate || !purchasePrice || !quantity) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    const newStock: StockHolding = {
      id: Date.now().toString(),
      symbol: symbol.toUpperCase(),
      name,
      purchaseDate: purchaseDate,
      purchasePrice: Number.parseFloat(purchasePrice),
      quantity: Number.parseInt(quantity),
      currentPrice: null,
    }

    setHoldings([...holdings, newStock])

    // Reset form
    setSymbol("")
    setName("")
    setPurchaseDate(new Date())
    setPurchasePrice("")
    setQuantity("")

    toast({
      title: "Stock added",
      description: `${newStock.symbol} has been added to your portfolio`,
    })
  }

  // Remove a stock from portfolio
  const removeStock = (id: string) => {
    setHoldings(holdings.filter((stock) => stock.id !== id))
    toast({
      title: "Stock removed",
      description: "The stock has been removed from your portfolio",
    })
  }

  // Calculate current value and potential return for a single stock
  const calculateReturn = async (id: string) => {
    try {
      setCalculatingIds((prev) => [...prev, id])

      const stockToCalculate = holdings.find((stock) => stock.id === id)
      if (!stockToCalculate) return

      // Use the server action to calculate returns
      // In development, we'll use the mock function if the API isn't available
      let results
      try {
        results = await calculateReturns([stockToCalculate])
      } catch (error) {
        console.log("Falling back to mock data:", error)
        results = await mockCalculateReturns([stockToCalculate])
      }

      if (results && results.length > 0) {
        const result = results[0]

        setHoldings(
          holdings.map((stock) => {
            if (stock.id === id) {
              return {
                ...stock,
                currentPrice: result.currentPrice,
                currentValue: result.currentValue,
                returnValue: result.returnValue,
                returnPercentage: result.returnPercentage,
              }
            }
            return stock
          }),
        )
      }
    } catch (error) {
      console.error("Error calculating return:", error)
      toast({
        title: "Calculation failed",
        description: "Failed to calculate current return. Please try again.",
        variant: "destructive",
      })
    } finally {
      setCalculatingIds((prev) => prev.filter((item) => item !== id))
    }
  }

  // Calculate returns for all stocks
  const calculateAllReturns = async () => {
    try {
      setIsCalculatingAll(true)

      // Use the server action to calculate returns
      // In development, we'll use the mock function if the API isn't available
      let results
      try {
        results = await calculateReturns(holdings)
      } catch (error) {
        console.log("Falling back to mock data:", error)
        results = await mockCalculateReturns(holdings)
      }

      if (results && results.length > 0) {
        const updatedHoldings = holdings.map((stock) => {
          const result = results.find((r) => r.id === stock.id)
          if (result) {
            return {
              ...stock,
              currentPrice: result.currentPrice,
              currentValue: result.currentValue,
              returnValue: result.returnValue,
              returnPercentage: result.returnPercentage,
            }
          }
          return stock
        })

        setHoldings(updatedHoldings)

        toast({
          title: "Calculation complete",
          description: "All stock returns have been updated",
        })
      }
    } catch (error) {
      console.error("Error calculating all returns:", error)
      toast({
        title: "Calculation failed",
        description: "Failed to calculate returns. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsCalculatingAll(false)
    }
  }

  // Load portfolio from localStorage on initial render
  useEffect(() => {
    const savedPortfolio = localStorage.getItem("portfolio")
    if (savedPortfolio) {
      try {
        const parsed = JSON.parse(savedPortfolio)
        // Convert string dates back to Date objects
        const portfolioWithDates = parsed.map((stock: any) => ({
          ...stock,
          purchaseDate: new Date(stock.purchaseDate),
        }))
        setHoldings(portfolioWithDates)
      } catch (error) {
        console.error("Error loading portfolio from localStorage:", error)
      }
    }
  }, [])

  // Save portfolio to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("portfolio", JSON.stringify(holdings))
  }, [holdings])

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight">Portfolio Management</h1>
        <Button onClick={calculateAllReturns} disabled={isCalculatingAll || holdings.length === 0}>
          {isCalculatingAll ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Calculating...
            </>
          ) : (
            <>
              <Calculator className="h-4 w-4 mr-2" />
              Calculate All Returns
            </>
          )}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Investment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${totalInvestment.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Current Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${totalCurrentValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Return</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold flex items-center">
              ${Math.abs(totalReturn).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              {totalReturn >= 0 ? (
                <ArrowUp className="ml-1 h-5 w-5 text-green-500" />
              ) : (
                <ArrowDown className="ml-1 h-5 w-5 text-red-500" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Return Percentage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalReturnPercentage >= 0 ? "text-green-500" : "text-red-500"}`}>
              {totalReturnPercentage >= 0 ? "+" : ""}
              {totalReturnPercentage.toFixed(2)}%
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add New Stock</CardTitle>
          <CardDescription>Enter the details of a stock you've purchased</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
            <div className="space-y-2">
              <Label htmlFor="symbol">Stock Symbol</Label>
              <Input id="symbol" placeholder="e.g. AAPL" value={symbol} onChange={(e) => setSymbol(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Company Name</Label>
              <Input id="name" placeholder="e.g. Apple Inc." value={name} onChange={(e) => setName(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Purchase Date</Label>
              <DatePicker date={purchaseDate} setDate={setPurchaseDate} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Purchase Price ($)</Label>
              <Input
                id="price"
                type="number"
                placeholder="0.00"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                placeholder="0"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={addStock}>
            <Plus className="h-4 w-4 mr-2" />
            Add to Portfolio
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Your Portfolio</CardTitle>
          <CardDescription>Manage your stock holdings</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Purchase Date</TableHead>
                <TableHead className="text-right">Purchase Price</TableHead>
                <TableHead className="text-right">Quantity</TableHead>
                <TableHead className="text-right">Current Price</TableHead>
                <TableHead className="text-right">Current Value</TableHead>
                <TableHead className="text-right">Return</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {holdings.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center">
                    No stocks in your portfolio yet
                  </TableCell>
                </TableRow>
              ) : (
                holdings.map((stock) => {
                  const currentValue = stock.currentPrice ? stock.currentPrice * stock.quantity : null
                  const investmentValue = stock.purchasePrice * stock.quantity
                  const returnValue = currentValue !== null ? currentValue - investmentValue : null
                  const returnPercentage = returnValue !== null ? (returnValue / investmentValue) * 100 : null
                  const isCalculating = calculatingIds.includes(stock.id)

                  return (
                    <TableRow key={stock.id}>
                      <TableCell className="font-medium">{stock.symbol}</TableCell>
                      <TableCell>{stock.name}</TableCell>
                      <TableCell>{format(stock.purchaseDate, "MMM d, yyyy")}</TableCell>
                      <TableCell className="text-right">${stock.purchasePrice.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{stock.quantity}</TableCell>
                      <TableCell className="text-right">
                        {isCalculating ? (
                          <Badge variant="outline" className="animate-pulse">
                            Calculating...
                          </Badge>
                        ) : stock.currentPrice ? (
                          `$${stock.currentPrice.toFixed(2)}`
                        ) : (
                          <Badge variant="outline">Not calculated</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {isCalculating ? "-" : currentValue !== null ? `$${currentValue.toFixed(2)}` : "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        {isCalculating ? (
                          "-"
                        ) : returnValue !== null && returnPercentage !== null ? (
                          <div className={returnValue >= 0 ? "text-green-500" : "text-red-500"}>
                            ${Math.abs(returnValue).toFixed(2)} ({returnValue >= 0 ? "+" : ""}
                            {returnPercentage.toFixed(2)}%)
                          </div>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => calculateReturn(stock.id)}
                            disabled={isCalculating}
                            title="Calculate current return"
                          >
                            {isCalculating ? (
                              <RefreshCw className="h-4 w-4 animate-spin" />
                            ) : (
                              <Calculator className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => removeStock(stock.id)}
                            title="Remove from portfolio"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

