import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowUp, ArrowDown, TrendingUp, Newspaper, Briefcase, LineChart } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"

export default function HomePage() {
  // Mock data for the home page
  const trendingStocks = [
    { symbol: "AAPL", name: "Apple Inc.", price: 182.52, change: 1.25, percentChange: 0.69 },
    { symbol: "MSFT", name: "Microsoft Corp.", price: 417.88, change: 2.43, percentChange: 0.58 },
    { symbol: "GOOGL", name: "Alphabet Inc.", price: 152.19, change: -0.89, percentChange: -0.58 },
    { symbol: "AMZN", name: "Amazon.com Inc.", price: 178.75, change: 1.12, percentChange: 0.63 },
  ]

  const upcomingIPOs = [
    { symbol: "STRP", name: "Stripe Inc.", date: "June 15, 2024", expectedPrice: "$90-110" },
    { symbol: "INST", name: "Instacart", date: "July 8, 2024", expectedPrice: "$35-40" },
    { symbol: "RDDT", name: "Reddit Inc.", date: "August 2, 2024", expectedPrice: "$25-30" },
  ]

  const marketNews = [
    {
      id: 1,
      title: "Fed Signals Potential Rate Cut in September",
      source: "Financial Times",
      time: "2 hours ago",
      category: "Economy",
    },
    {
      id: 2,
      title: "Tech Stocks Rally as Inflation Concerns Ease",
      source: "Wall Street Journal",
      time: "4 hours ago",
      category: "Markets",
    },
    {
      id: 3,
      title: "Oil Prices Surge Amid Middle East Tensions",
      source: "Bloomberg",
      time: "6 hours ago",
      category: "Commodities",
    },
    {
      id: 4,
      title: "Retail Sales Beat Expectations in Q2",
      source: "CNBC",
      time: "8 hours ago",
      category: "Economy",
    },
    {
      id: 5,
      title: "New Regulations for Cryptocurrency Exchanges Announced",
      source: "Reuters",
      time: "10 hours ago",
      category: "Crypto",
    },
  ]

  return (
    <div className="container py-6 space-y-8">
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Market Overview</h1>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-sm">
              S&P 500: 5,234.18 (+0.32%)
            </Badge>
            <Badge variant="outline" className="text-sm">
              NASDAQ: 16,742.39 (+0.58%)
            </Badge>
            <Badge variant="outline" className="text-sm">
              DOW: 38,671.22 (+0.21%)
            </Badge>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Trending Stocks
              </CardTitle>
              <CardDescription>Top performing stocks today</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {trendingStocks.map((stock) => (
                  <div key={stock.symbol} className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">{stock.symbol}</div>
                      <div className="text-sm text-muted-foreground">{stock.name}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${stock.price}</div>
                      <div
                        className={cn(
                          "text-sm flex items-center",
                          stock.change >= 0 ? "text-green-500" : "text-red-500",
                        )}
                      >
                        {stock.change >= 0 ? (
                          <ArrowUp className="h-3 w-3 mr-1" />
                        ) : (
                          <ArrowDown className="h-3 w-3 mr-1" />
                        )}
                        {stock.change >= 0 ? "+" : ""}
                        {stock.change} ({stock.percentChange}%)
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href="/predictions">
                    <LineChart className="h-4 w-4 mr-2" />
                    View Predictions
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Upcoming IPOs
              </CardTitle>
              <CardDescription>New offerings to watch</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingIPOs.map((ipo) => (
                  <div key={ipo.symbol} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">
                        {ipo.symbol}: {ipo.name}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {ipo.date}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">Expected Price Range: {ipo.expectedPrice}</div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href="/ipo-calendar">View All IPOs</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 lg:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Newspaper className="h-5 w-5" />
                Market News
              </CardTitle>
              <CardDescription>Latest financial updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {marketNews.slice(0, 4).map((news) => (
                  <div key={news.id} className="space-y-1">
                    <div className="font-medium hover:underline cursor-pointer">{news.title}</div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>{news.source}</span>
                      <span className="mx-1">•</span>
                      <span>{news.time}</span>
                      <Badge variant="outline" className="ml-2 text-xs">
                        {news.category}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Button variant="outline" size="sm" className="w-full">
                  View All News
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section>
        <Tabs defaultValue="market-insights">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold tracking-tight">Market Insights</h2>
            <TabsList>
              <TabsTrigger value="market-insights">Market Insights</TabsTrigger>
              <TabsTrigger value="sector-performance">Sector Performance</TabsTrigger>
              <TabsTrigger value="economic-calendar">Economic Calendar</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="market-insights" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Market Sentiment Analysis</CardTitle>
                <CardDescription>
                  Overall market sentiment based on news, social media, and analyst reports
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Sentiment Analysis Chart</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sector-performance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Sector Performance</CardTitle>
                <CardDescription>Performance comparison across different market sectors</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Sector Performance Chart</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="economic-calendar" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Economic Calendar</CardTitle>
                <CardDescription>Upcoming economic events and announcements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Fed Interest Rate Decision</div>
                      <div className="text-sm text-muted-foreground">June 12, 2024 • 2:00 PM ET</div>
                    </div>
                    <Badge>High Impact</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">US Unemployment Rate</div>
                      <div className="text-sm text-muted-foreground">June 7, 2024 • 8:30 AM ET</div>
                    </div>
                    <Badge>High Impact</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">US GDP (Q2)</div>
                      <div className="text-sm text-muted-foreground">June 27, 2024 • 8:30 AM ET</div>
                    </div>
                    <Badge variant="outline">Medium Impact</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>
    </div>
  )
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(" ")
}

