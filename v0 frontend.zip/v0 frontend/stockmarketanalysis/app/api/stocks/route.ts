import { NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"

const execPromise = promisify(exec)

// Function to execute Python scripts
async function runPythonScript(scriptName: string, args: string[] = []) {
  try {
    const { stdout, stderr } = await execPromise(`python scripts/${scriptName}.py ${args.join(" ")}`)

    if (stderr) {
      console.error(`Python script error: ${stderr}`)
      throw new Error(stderr)
    }

    return JSON.parse(stdout)
  } catch (error) {
    console.error("Error executing Python script:", error)
    throw error
  }
}

// GET endpoint to fetch current stock prices
export async function GET(request: Request) {
  const url = new URL(request.url)
  const symbols = url.searchParams.get("symbols")

  if (!symbols) {
    return NextResponse.json({ error: "No symbols provided" }, { status: 400 })
  }

  try {
    // Call your Python script to get current prices
    const data = await runPythonScript("get_stock_prices", symbols.split(","))
    return NextResponse.json(data)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch stock prices" }, { status: 500 })
  }
}

// POST endpoint to calculate potential returns
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { holdings } = body

    if (!holdings || !Array.isArray(holdings)) {
      return NextResponse.json({ error: "Invalid holdings data" }, { status: 400 })
    }

    // Extract symbols for price lookup
    const symbols = holdings.map((stock) => stock.symbol)

    // Call your Python script to calculate returns
    const data = await runPythonScript("calculate_returns", [JSON.stringify(holdings)])
    return NextResponse.json(data)
  } catch (error) {
    return NextResponse.json({ error: "Failed to calculate returns" }, { status: 500 })
  }
}

