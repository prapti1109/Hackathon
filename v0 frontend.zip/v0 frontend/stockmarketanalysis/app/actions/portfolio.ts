"use server"

// Type definitions
export interface StockHolding {
  id: string
  symbol: string
  name: string
  purchaseDate: Date
  purchasePrice: number
  quantity: number
  currentPrice: number | null
  currentValue?: number | null
  returnValue?: number | null
  returnPercentage?: number | null
}

// Function to fetch current stock prices
export async function fetchStockPrices(symbols: string[]) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ""}/api/stocks?symbols=${symbols.join(",")}`, {
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error("Failed to fetch stock prices")
    }

    const data = await response.json()
    return data.prices || {}
  } catch (error) {
    console.error("Error fetching stock prices:", error)
    throw error
  }
}

// Function to calculate returns for holdings
export async function calculateReturns(holdings: StockHolding[]) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ""}/api/stocks`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ holdings }),
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error("Failed to calculate returns")
    }

    const data = await response.json()
    return data.results || []
  } catch (error) {
    console.error("Error calculating returns:", error)
    throw error
  }
}

// Mock function for development when Python scripts aren't available
export async function mockCalculateReturns(holdings: StockHolding[]) {
  // Mock prices for demonstration
  const mockPrices: Record<string, number> = {
    AAPL: 182.52,
    MSFT: 417.88,
    GOOGL: 152.19,
    AMZN: 178.75,
    META: 474.99,
    TSLA: 177.5,
    NVDA: 925.75,
    "BRK.B": 408.32,
    JPM: 198.47,
    V: 275.96,
  }

  return holdings.map((holding) => {
    const currentPrice = mockPrices[holding.symbol] || Math.random() * 500 + 50
    const currentValue = currentPrice * holding.quantity
    const investmentValue = holding.purchasePrice * holding.quantity
    const returnValue = currentValue - investmentValue
    const returnPercentage = (returnValue / investmentValue) * 100

    return {
      id: holding.id,
      symbol: holding.symbol,
      currentPrice,
      currentValue,
      returnValue,
      returnPercentage,
    }
  })
}

